package com.example.pocketllm_lite

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
